import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, ShoppingCart, User as UserIcon } from 'lucide-react';
import { useStore } from '../store/useStore';
import { motion, AnimatePresence } from 'framer-motion';

export const Navbar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { isAuthenticated, user, toggleLoginModal, cart } = useStore();

  return (
    <nav className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="text-xl font-bold">
              StyleStore
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link to="/products" className="hover:text-gray-600">All Products</Link>
            <Link to="/category/men" className="hover:text-gray-600">Men</Link>
            <Link to="/category/women" className="hover:text-gray-600">Women</Link>
            
            <Link to="/cart" className="relative">
              <ShoppingCart className="h-6 w-6" />
              {cart.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                  {cart.length}
                </span>
              )}
            </Link>

            {isAuthenticated ? (
              <Link to="/profile" className="hover:text-gray-600">
                <UserIcon className="h-6 w-6" />
              </Link>
            ) : (
              <button
                onClick={toggleLoginModal}
                className="bg-black text-white px-4 py-2 rounded-md hover:bg-gray-800"
              >
                Login
              </button>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-gray-600"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden"
          >
            <div className="px-2 pt-2 pb-3 space-y-1">
              <Link
                to="/products"
                className="block px-3 py-2 rounded-md hover:bg-gray-100"
              >
                All Products
              </Link>
              <Link
                to="/category/men"
                className="block px-3 py-2 rounded-md hover:bg-gray-100"
              >
                Men
              </Link>
              <Link
                to="/category/women"
                className="block px-3 py-2 rounded-md hover:bg-gray-100"
              >
                Women
              </Link>
              <Link
                to="/cart"
                className="block px-3 py-2 rounded-md hover:bg-gray-100"
              >
                Cart
              </Link>
              {isAuthenticated ? (
                <Link
                  to="/profile"
                  className="block px-3 py-2 rounded-md hover:bg-gray-100"
                >
                  Profile
                </Link>
              ) : (
                <button
                  onClick={toggleLoginModal}
                  className="w-full text-left px-3 py-2 rounded-md hover:bg-gray-100"
                >
                  Login
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};