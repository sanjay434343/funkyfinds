import { motion } from 'framer-motion';
import { Minus, Plus, X } from 'lucide-react';
import { CartItem as CartItemType } from '../types';
import { useStore } from '../store/useStore';

interface CartItemProps {
  item: CartItemType;
  product: any;
}

export const CartItem = ({ item, product }: CartItemProps) => {
  const { removeFromCart } = useStore();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="flex gap-4 border-b border-gray-200 py-4"
    >
      <img
        src={product.images[0]}
        alt={product.name}
        className="w-24 h-24 object-cover rounded-lg"
      />
      
      <div className="flex-1">
        <div className="flex justify-between">
          <h3 className="font-medium">{product.name}</h3>
          <button
            onClick={() => removeFromCart(product.id)}
            className="text-gray-400 hover:text-red-500 transition-colors"
          >
            <X size={20} />
          </button>
        </div>
        
        <div className="mt-2 text-sm text-gray-500">
          <p>Size: {item.size}</p>
          <p>Color: {item.color}</p>
        </div>
        
        <div className="mt-2 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <button className="p-1 hover:bg-gray-100 rounded">
              <Minus size={16} />
            </button>
            <span>{item.quantity}</span>
            <button className="p-1 hover:bg-gray-100 rounded">
              <Plus size={16} />
            </button>
          </div>
          <span className="font-medium">${product.price * item.quantity}</span>
        </div>
      </div>
    </motion.div>
  );
};