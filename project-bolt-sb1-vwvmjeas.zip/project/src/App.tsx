import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { LoginModal } from './components/LoginModal';
import { CartPage } from './pages/CartPage';
import { useStore } from './store/useStore';
import { auth } from './lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { HeroSection } from './components/HeroSection';
import { FeaturedProducts } from './components/FeaturedProducts';
import { ProductView } from './pages/ProductView';
import { CategoryPage } from './pages/CategoryPage';
import { AllProducts } from './pages/AllProducts';

function App() {
  const { setUser, setIsAuthenticated } = useStore();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        const userData = {
          uid: user.uid,
          email: user.email || '',
          displayName: user.displayName || '',
          addresses: []
        };
        setUser(userData);
        setIsAuthenticated(true);
        localStorage.setItem('uid', user.uid);
      } else {
        setUser(null);
        setIsAuthenticated(false);
        localStorage.removeItem('uid');
      }
    });

    return () => unsubscribe();
  }, []);

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <LoginModal />
        <main>
          <Routes>
            <Route path="/" element={
              <>
                <HeroSection />
                <FeaturedProducts />
              </>
            } />
            <Route path="/products" element={<AllProducts />} />
            <Route path="/product/:id" element={<ProductView />} />
            <Route path="/category/:category" element={<CategoryPage />} />
            <Route path="/cart" element={<CartPage />} />
            <Route path="/checkout" element={<div>Checkout Page</div>} />
            <Route path="/profile" element={<div>Profile Page</div>} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;