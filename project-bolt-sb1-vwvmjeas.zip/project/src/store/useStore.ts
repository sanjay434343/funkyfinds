import { create } from 'zustand';
import { User, CartItem } from '../types';

interface Store {
  user: User | null;
  isAuthenticated: boolean;
  cart: CartItem[];
  isLoginModalOpen: boolean;
  setUser: (user: User | null) => void;
  setIsAuthenticated: (status: boolean) => void;
  addToCart: (item: CartItem) => void;
  removeFromCart: (productId: string) => void;
  toggleLoginModal: () => void;
}

export const useStore = create<Store>((set) => ({
  user: null,
  isAuthenticated: false,
  cart: [],
  isLoginModalOpen: false,
  setUser: (user) => set({ user }),
  setIsAuthenticated: (status) => set({ isAuthenticated: status }),
  addToCart: (item) => set((state) => ({ cart: [...state.cart, item] })),
  removeFromCart: (productId) =>
    set((state) => ({
      cart: state.cart.filter((item) => item.productId !== productId),
    })),
  toggleLoginModal: () =>
    set((state) => ({ isLoginModalOpen: !state.isLoginModalOpen })),
}));